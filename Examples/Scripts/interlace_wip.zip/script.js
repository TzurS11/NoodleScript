// ██╗███╗░░░███╗██████╗░░█████╗░██████╗░████████╗░█████╗░███╗░░██╗████████╗
// ██║████╗░████║██╔══██╗██╔══██╗██╔══██╗╚══██╔══╝██╔══██╗████╗░██║╚══██╔══╝
// ██║██╔████╔██║██████╔╝██║░░██║██████╔╝░░░██║░░░███████║██╔██╗██║░░░██║░░░
// ██║██║╚██╔╝██║██╔═══╝░██║░░██║██╔══██╗░░░██║░░░██╔══██║██║╚████║░░░██║░░░
// ██║██║░╚═╝░██║██║░░░░░╚█████╔╝██║░░██║░░░██║░░░██║░░██║██║░╚███║░░░██║░░░
// ╚═╝╚═╝░░░░░╚═╝╚═╝░░░░░░╚════╝░╚═╝░░╚═╝░░░╚═╝░░░╚═╝░░╚═╝╚═╝░░╚══╝░░░╚═╝░░░
// if you see this it means that you downloaded the map from the beat saber mapping discord
// i DO NOT allow you to upload this map to beat saver so dont ask, even if you decide you wanna finish it for some reason :/
// i simply put it here because i want people to know how i make my noodle maps by not only uploading the script
// this is the first time im using remapper by swifter so i might me a complete fucking idiot
// you can simply drag and drop the script in the wip folder(ONLY THERE) and play what is already made probably forever(and now for real!)
// lastly i allow you to use any of the already made environments in the environment folder(no need to give me credit if you use them)
// you can also use any part of this script for your map :D
// i hope you have a good time exploring here and a good time playing the map if you decide you wanna play it, have a nice day.


//!------------------------------------Golbal------------------------------------
const fs = require("fs");
const three = require("three")
const BPM = 150;
const halfJumpDuration = 1.75;
const diffName = "ExpertPlusStandard.dat"
const { BlenderEnvironment, Difficulty, ENV, Environment } = require("swifter_remapper");
const pillarToNoodleUnits = 0.1495;

let externalInfo = JSON.parse(fs.readFileSync("externalInfo.dat"))
externalInfo.runs++;
fs.writeFileSync("externalInfo.dat", JSON.stringify(externalInfo, null, 0));






//!----------------------------------Javascript----------------------------------
//i could try to make everything with Remapper but im too dumb and im just working faster like that
let difficulty = JSON.parse(fs.readFileSync(diffName))

if (!difficulty._customData) difficulty._customData = {};
if (!difficulty._customData._customEvents) difficulty._customData._customEvents = []
if (!difficulty._customData._environment) difficulty._customData._environment = []

const _customData = difficulty._customData;
const _obstacles = difficulty._obstacles;
const _notes = difficulty._notes;
const _customEvents = _customData._customEvents;
const _environment = _customData._environment;
const _events = difficulty._events;

function Random(min, max, round) {
    if (round == false || round == undefined) return Number((Math.random() * (max + 1 - min) + min).toFixed(3));
    if (round == true) return Math.round(Math.random() * (max + 1 - min) + min);
}
//#region Blender to environment

function EnvArrLengthByTrack(track) {
    let length = 0;
    _notes.forEach((x) => {
        if (x._customData && x._customData._track === track) {
            length++;
        }
    });
    return length;
}
const trackNameArr = [
    EnvArrLengthByTrack("environment1:Cubes"),
    EnvArrLengthByTrack("environment2:Cubes"),
];
var envDups = trackNameArr[0];
for (let i = 0; i < trackNameArr.length; i++) {
    if (envDups < trackNameArr[i]) {
        envDups = trackNameArr[i];
    }
}
for (let i = 0; i < envDups; i++) {
    _environment.push({
        _id: "\\]PillarPair \\(1\\)\\.\\[0\\]PillarL\\.\\[0\\]Pillar$",
        _lookupMethod: "Regex",
        _duplicate: 1,
        _position: [0, 0, -1000000],
        _scale: [1, 1, 1],
        _rotation: [0, 0, 0],
        _track: "environment:" + i,
        _active: true,
    });
}
function vectorFromRotation(vectorRot, length) {
    const deg2rad = Math.PI / 180;
    var mathRot = copy(vectorRot);

    mathRot[0] *= deg2rad;
    mathRot[1] *= deg2rad;
    mathRot[2] *= deg2rad;

    var rotVector = new three.Vector3(0, length, 0).applyEuler(
        new three.Euler(...mathRot, "YXZ")
    );
    return [rotVector.x, rotVector.y, rotVector.z];
}

function copy(obj) {
    if (typeof obj != "object") return obj;

    var newObj = Array.isArray(obj) ? [] : {};

    for (const key in obj) {
        newObj[key] = copy(obj[key]);
    }
    return newObj;
}
let amountused = 0;
let lastEnv = "";
function switchEnvironment(TRACK, TIME, MIN, MAX, ZOFFSET, ROUNDING) {
    amountused = 0;
    let trackPlusOne = 0;
    console.log(`Switched ${lastEnv} to ${TRACK} at beat ${TIME}`);
    lastEnv = TRACK;
    trackPlusOne = 0;
    _notes.forEach((x) => {
        if (x._customData && x._customData._track == TRACK) {
            var y = copy(x);

            var pillarPos = y._customData._animation._definitePosition[0];
            var pillarRot = y._customData._animation._localRotation[0];
            var pillarScale = y._customData._animation._scale[0];

            pillarPos.pop();
            pillarRot.pop();
            pillarScale.pop();

            var offset = vectorFromRotation(pillarRot, (pillarScale[1] / 2) * 0.87);

            pillarScale[0] *= pillarToNoodleUnits;
            pillarScale[1] *= pillarToNoodleUnits / 32;
            pillarScale[2] *= pillarToNoodleUnits;

            pillarPos[1] += 0.09;
            pillarPos[2] += 0.65 * (1 / 0.6);

            pillarPos[0] += offset[0];
            pillarPos[1] += offset[1];
            pillarPos[2] += offset[2] + ZOFFSET;
            amountused++;
            _customEvents.push({
                _time: TIME + Random(MIN, MAX, ROUNDING),
                _type: "AnimateTrack",
                _data: {
                    _track: "environment:" + trackPlusOne,
                    _duration: 1,
                    _position: [[...pillarPos, 0]],
                    _rotation: [[...pillarRot, 0]],
                    _scale: [[...pillarScale, 0]],
                },
            });
            trackPlusOne++;
        }
    });
    for (let i = trackPlusOne; i < envDups; i++) {
        _customEvents.push({
            _time: TIME + MAX + Random(1, 5),
            _type: "AnimateTrack",
            _data: {
                _track: "environment:" + i,
                _duration: 1,
                _position: [[0, 0, -1000000, 0]],
                _rotation: [[0, 0, 0, 0]],
                _scale: [[1, 1, 1, 0]],
            },
        });
    }
    difficulty._notes = difficulty._notes.filter(
        (x) => !x._customData || x._customData._track !== TRACK
    );
}
let something = 0;
function EmptyEnv(TIME, MIN, MAX) {
    something = 0;
    for (let i = 0; i < amountused; i++) {
        _customEvents.push({
            _time: TIME + Random(MIN, MAX),
            _type: "AnimateTrack",
            _data: {
                _track: "environment:" + i,
                _duration: 1,
                _position: [[0, 0, -1000000, 0]],
                _rotation: [[0, 0, 0, 0]],
                _scale: [[1, 1, 1, 0]],
            },
        });
        something++;
    }
    _customEvents.push({
        _time: TIME,
        _type: "AnimateTrack",
        _data: {
            _track: "highClouds",
            _duration: 1,
            _position: [[0, 0, -1000000, 0]],
        },
    });
    console.log(` Removed ${lastEnv} at beat ${TIME}`);
}
//#endregion


function RoundNum(num) {
    return Number(num.toFixed(3))
}

function Parent(children, parent, positionStay) {
    _customEvents.push(
        {
            "_time": 1,
            "_type": "AssignTrackParent",
            "_data": {
                "_childrenTracks": children,
                "_parentTrack": parent,
                "_worldPositionStays": positionStay
            }
        },
    )
}

function NumArray(start, end) {
    let arr = [];
    for (let i = start; i <= end; i++) {
        arr.push(i);
    }
    return arr;
}

function TestLights(beat, type, lightID) {
    _events.push(
        {
            "_time": beat,
            "_type": type,
            "_value": 5,
            "_customData": {
                "_color": [
                    0,
                    0,
                    0,
                    10
                ],
                "_lightID": lightID
            }
        }
    )
}
// TestLights(0, 1, 104 + 7)

function PointsOnSphere(radius, s, t) {
    let xOnCicle = radius * Math.cos(s) * Math.sin(t)
    let yOnCicle = radius * Math.sin(s) * Math.sin(t)
    let zOnCicle = radius * Math.cos(t)
    return [RoundNum(xOnCicle), RoundNum(yOnCicle), RoundNum(zOnCicle)];
}

function HSVtoRGB(h, s, v, multiplier) {
    var r, g, b, i, f, p, q, t;
    if (arguments.length === 1) {
        (s = h.s), (v = h.v), (h = h.h);
    }
    i = Math.floor(h * 6);
    f = h * 6 - i;
    p = v * (1 - s);
    q = v * (1 - f * s);
    t = v * (1 - (1 - f) * s);
    switch (i % 6) {
        case 0:
            (r = v), (g = t), (b = p);
            break;
        case 1:
            (r = q), (g = v), (b = p);
            break;
        case 2:
            (r = p), (g = v), (b = t);
            break;
        case 3:
            (r = p), (g = q), (b = v);
            break;
        case 4:
            (r = t), (g = p), (b = v);
            break;
        case 5:
            (r = v), (g = p), (b = q);
            break;
    }
    return [RoundNum(r * multiplier), RoundNum(g * multiplier), RoundNum(b * multiplier)]
}

function circleGen(beat, duration, Xc, Yc, Z, radius, amount, track, l, h) {
    for (let i = 0; i < amount; i++) {
        let angle = (Math.PI * 2) / amount;
        let rot = (360 / amount) * i;
        let radians = angle * i;
        let w = 2 * radius * Math.tan(Math.PI / amount);
        let X = Xc + Math.cos(radians) * radius - w / 2;
        let Y = Yc + Math.sin(radians) * radius - h / 2;
        _obstacles.push({
            _time: beat,
            _duration: duration,
            _lineIndex: 0,
            _type: 0,
            _width: 0,
            _customData: {
                _interactable: false,
                _track: track,
                _rotation: [0, 0, 0],
                _scale: [w, h, l],
                _localRotation: [0, 0, 90 + rot],
                _position: [X, Y, 0],
                _color: [1, 1, 1, 1, 0],
                _animation: {
                    _definitePosition: [
                        [0, 0, Z, 0],
                        [0, 0, Z, 1],
                    ],
                },
            },
        });
    }
}


function ApplyTrackNotes(start, end, type, track) {
    if (type != 0 || type != 1 || type != 3) return;
    switch (type) {
        case (0):
            track += ":Left"
            break;
        case (1):
            track += ":Right"
            break;
    }
    _notes.forEach((x) => {
        if (x._time >= start && x._time < end && x._type == type) {
            if (!x._customData) x._customData = {};
            if (!x._customData._track) x._customData._track = [];
            if (typeof x._customData._track == "string") {
                x._customData._track = [x._customData._track, track];
            } else {
                x._customData._track.push(track)
            }
        }
    })
}



/**
 * @param beat The starting beat
 * @param duration The amount of time (duration)
 * @param pos position to move the player
 * @param rot rotation of the player
 */
function MovePlayer(beat, duration, pos, rot) {
    _customEvents.push(
        {
            "_time": beat,
            "_type": "AnimateTrack",
            "_data": {
                "_track": "player",
                "_duration": duration,
                _position: pos,
                _rotation: rot
            }
        },
        {
            "_time": beat,
            "_type": "AnimateTrack",
            "_data": {
                "_track": "skyLightBoxParent",
                "_duration": duration,
                _position: pos,
                _rotation: rot
            }
        }
    )
}

function FuckThis(id, completely) {
    if (completely == true || completely == undefined)
        _environment.push({
            _id: id,
            _lookupMethod: "Regex",
            _active: false
        })
    else _environment.push({
        _id: id,
        _lookupMethod: "Regex",
        _position: [0, 0, -10000000]
    })

}


FuckThis("MagicDoorSprite$", true)
FuckThis("LowCloudsGenerator", false)
FuckThis("PillarTrackLaneRingsR( \\(\\d*\\))?$", true)
FuckThis("PillarPair( \\(\\d*\\))?$", false)
FuckThis("TrackMirror", true)
FuckThis("PlayersPlace$", false)
FuckThis("NarrowGameHUD$", true)
FuckThis("t\\.\\[\\d*\\]Construction", true)
FuckThis("GlowLine(L|R|C)$", true)
FuckThis("DirectionalLight", true)

Parent(["skyLightBox"], "skyLightBoxParent", true)

_environment.push(
    {
        _id: "SmallPillarPair \\(2\\)\\.\\[\\d*\\]PillarL\\.\\[\\d*\\]LaserL$",
        _lookupMethod: "Regex",
        _duplicate: 1,
        _track: "horizonLazerLong:Left",
        _position: [0, 0, 450],
        _rotation: [0, 0, 90],
        // _scale: [1, 0.05, 1],
        _lightID: 98,
    },
    {
        _id: "SmallPillarPair \\(2\\)\\.\\[\\d*\\]PillarL\\.\\[\\d*\\]LaserL$",
        _lookupMethod: "Regex",
        _duplicate: 1,
        _track: "horizonLazerLong:Right",
        _position: [0, 0, 450],
        _rotation: [0, 0, -90],
        // _scale: [1, 0.05, 1],
        _lightID: 99,
    },
    {
        _id: "SmallPillarPair \\(2\\)\\.\\[\\d*\\]PillarL\\.\\[\\d*\\]LaserL\\(Clone\\)\\.\\[\\d*\\]BoxLight",
        _lookupMethod: "Regex",
        _active: false
    },
)
_events.forEach((x) => {
    if (x._type == 1 && x._customData && (x._customData._lightID == 98 || x._customData._lightID == 99)) {
        x._customData._lightID = [98, 99]
    }
})

let oldAngle = 90;
function rotateHorizon(beat, duration, angle, easing) {
    _customEvents.push(
        {
            "_time": beat,
            "_type": "AnimateTrack",
            "_data": {
                "_track": "horizonLazerLong:Left",
                "_duration": duration,
                _rotation: [[0, 0, oldAngle, 0], [0, 0, angle, 1, easing]]
            }
        },
        {
            "_time": beat,
            "_type": "AnimateTrack",
            "_data": {
                "_track": "horizonLazerLong:Right",
                "_duration": duration,
                _rotation: [[0, 0, (180 - oldAngle) * -1, 0], [0, 0, (180 - angle) * -1, 1, easing]]
            }
        }
    )
    oldAngle = angle;
}

rotateHorizon(327, 359 - 327, 105, "easeLinear")
rotateHorizon(359, 0.1, 90, "easeLinear")

_customEvents.push( //fog animations
    {
        "_time": 0,
        "_type": "AssignFogTrack",
        "_data": {
            "_track": "fog"
        }
    },
    {
        "_time": 1,
        "_type": "AnimateTrack",
        "_data": {
            "_track": "fog",
            "_duration": 1,
            _startY: [[-100000, 0]]
        }
    },
    // {
    //     "_time": 327,
    //     "_type": "AnimateTrack",
    //     "_data": {
    //         "_track": "fog",
    //         "_duration": 1,
    //         _startY: [[-10, 0]]
    //     }
    // },

    // {
    //     "_time": 199,
    //     "_type": "AnimateTrack",
    //     "_data": {
    //         "_track": "fog",
    //         "_duration": 1,
    //         _startY: [[-20, 0]]
    //     }
    // }
)

//player movemment
MovePlayer(1, 1, [[0, 0, 0, 0]], [[0, 0, 0, 0]])
MovePlayer(199, 327 - 199, [[0, 0, 0, 0], [0, 0, 550, 1]], [[0, 0, 0, 0]])
MovePlayer(327, 391 - 327, [[0, 0, 0, 0], [0, 0, 100, 1]], [[0, 0, 0, 0]])
MovePlayer(359, 391 - 359, [[0, 0, 0, 0], [0, 10, 15, 1]], [[0, 0, 0, 0]])
MovePlayer(391, 1, [[0, 0, 0, 0]], [[0, 0, 0, 0]])
_environment.push(//high clouds animation
    {
        _id: "HighCloudsGenerator$",
        _lookupMethod: "Regex",
        _track: "highClouds",
        _position: [0, 0, -1000000]
    },
    {
        _id: "HighCloudsGenerator$",
        _lookupMethod: "Regex",
        _track: "environment3:highclouds1",
        _duplicate: 1,
        _scale: [2, 0.1, 1],
        _rotation: [-90, 0, 0],
        _position: [0, 0, 400]
    },
    {
        _id: "HighCloudsGenerator$",
        _lookupMethod: "Regex",
        _track: "environment3:highclouds1",
        _duplicate: 1,
        _scale: [2 / 2, 0.1 / 2, 1 / 2],
        _rotation: [-90, 0, 0],
        _position: [0, 0, 350]
    },
    {
        _id: "HighCloudsGenerator$",
        _lookupMethod: "Regex",
        _track: "environment3:highclouds1",
        _duplicate: 1,
        _scale: [2 / 4, 0.1 / 4, 1 / 4],
        _rotation: [-90, 0, 0],
        _position: [0, 0, 300]
    },
    {
        _id: "HighCloudsGenerator$",
        _lookupMethod: "Regex",
        _track: "environment3:highclouds2",
        _duplicate: 1,
        _scale: [2, 4, 2],
        // _rotation: [-90, 0, 0],
        _position: [0, 0, 0]
    },
)
Parent(["environment3:highclouds1"], "environment3:highclouds1:Parent", true)

_customEvents.push(
    {
        "_time": 0,
        "_type": "AnimateTrack",
        "_data": {
            "_track": "highClouds",
            "_duration": 1,
            _position: [[0, -100000, 0, 0]],
        }
    },
    {
        "_time": 0,
        "_type": "AnimateTrack",
        "_data": {
            "_track": "environment3:highclouds2",
            "_duration": 1,
            _position: [[0, -100000, 0, 0]],
        }
    },
    {
        "_time": 359,
        "_type": "AnimateTrack",
        "_data": {
            "_track": "environment3:highclouds2",
            "_duration": 1,
            _position: [[0, 0, 0, 0]],
        }
    },
    {
        "_time": 391,
        "_type": "AnimateTrack",
        "_data": {
            "_track": "environment3:highclouds2",
            "_duration": 1,
            _position: [[0, -100000, 0, 0]],
        }
    },
    {
        "_time": 0,
        "_type": "AnimateTrack",
        "_data": {
            "_track": "environment3:highclouds1:Parent",
            "_duration": 1,
            _position: [[0, -100000, 0, 0]],
        }
    },
    {
        "_time": 327,
        "_type": "AnimateTrack",
        "_data": {
            "_track": "environment3:highclouds1:Parent",
            "_duration": 1,
            _position: [[0, 0, 0, 0]],
        }
    },
    {
        "_time": 359,
        "_type": "AnimateTrack",
        "_data": {
            "_track": "environment3:highclouds1:Parent",
            "_duration": 1,
            _position: [[0, -100000, 0, 0]],
        }
    },
)



_environment.push(//sun
    {
        _id: "BottomGlow$",
        _lookupMethod: "Regex",
        _track: "sun",
        _position: [0, 2, 150],
    },
)
for (let i = 0; i < 100; i += 7.2) {
    _environment.push({
        _id: "BottomGlow$",
        _lookupMethod: "Regex",
        _track: "sun",
        _duplicate: 1,
        _position: [0, 2, 150],
        _localRotation: [0, 0, i * 10],
    });
}
_customEvents.push(
    {
        "_time": 1,
        "_type": "AssignTrackParent",
        "_data": {
            "_childrenTracks": ["sun"],
            "_parentTrack": "sunParent",
            "_worldPositionStays": true
        }
    },
    {
        "_time": 199,
        "_type": "AnimateTrack",
        "_data": {
            "_track": "sunParent",
            "_duration": 1,
            _position: [[0, 0, 600, 1]],
        }
    },
    {
        "_time": 327,
        "_type": "AnimateTrack",
        "_data": {
            "_track": "sunParent",
            "_duration": 1,
            _position: [[0, 0, 400, 1]],
        }
    }
)

let distanceFromPlayer = 700;
_environment.push(//Big sky lightBox because in nothing else if you look to the sides you can see the render distance fucking my ass
    {
        _id: "SmallPillarPair \\(1\\)\\.\\[\\d*\\]PillarL\\.\\[\\d*\\]LaserL$",
        _lookupMethod: "Regex",
        _duplicate: 1,
        _track: "skyLightBox",
        _position: [900000 / 2, 1000, distanceFromPlayer],
        _rotation: [0, 0, 90],
        _scale: [900000, 900000, 1],
        _lightID: 100,
    },
    {
        _id: "SmallPillarPair \\(1\\)\\.\\[\\d*\\]PillarL\\.\\[\\d*\\]LaserL$",
        _lookupMethod: "Regex",
        _duplicate: 1,
        _track: "skyLightBox",
        _position: [distanceFromPlayer, 1000, -900000 / 2],
        _rotation: [90, 0, 0],
        _scale: [1, 900000, 900000],
        _lightID: 101,
    },
    {
        _id: "SmallPillarPair \\(1\\)\\.\\[\\d*\\]PillarL\\.\\[\\d*\\]LaserL$",
        _lookupMethod: "Regex",
        _duplicate: 1,
        _track: "skyLightBox",
        _position: [-1 * distanceFromPlayer, 1000, -900000 / 2],
        _rotation: [90, 0, 0],
        _scale: [1, 900000, 900000],
        _lightID: 102,
    },
    {
        _id: "SmallPillarPair \\(1\\)\\.\\[\\d*\\]PillarL\\.\\[\\d*\\]LaserL$",
        _lookupMethod: "Regex",
        _duplicate: 1,
        _track: "skyLightBox",
        _position: [900000 / 2, 1000, -1 * distanceFromPlayer],
        _rotation: [0, 0, 90],
        _scale: [900000, 900000, 1],
        _lightID: 103,
    },
);

_events.forEach(x => {
    if (x._customData && x._type == 1 && x._customData._lightID == 20) x._customData._lightID = [100, 101, 102, 103];
})


_customEvents.push(
    {
        "_time": 1,
        "_type": "AnimateTrack",
        "_data": {
            "_track": "starExplotion1",
            "_duration": 1,
            _dissolve: [[0, 0]]
        }
    },
    {
        "_time": 359,
        "_type": "AnimateTrack",
        "_data": {
            "_track": "starExplotion1",
            "_duration": 1,
            _dissolve: [[1, 0]]
        }
    },
    {
        "_time": 391,
        "_type": "AnimateTrack",
        "_data": {
            "_track": "starExplotion1",
            "_duration": 1,
            _dissolve: [[0, 0]]
        }
    }
)
for (let i = 0; i < 650; i++) {
    _obstacles.push(// totally didnt yoink if from alchamy(map that i just stopped mapping)
        {
            "_time": 345 + i / 16,
            "_lineIndex": 1,
            "_type": 0,
            "_duration": 20,
            "_width": 1,
            _customData: {
                _scale: [12, 3, 3],
                _track: "starExplotion1",
                _rotation: [0, 0, Random(0, 360)],
                _color: [1, 1, 10, -69],
                _animation: {
                    _localRotation: [[0, Random(0, 360), Random(-20, 20), 0], [0, Random(0, 360), Random(-20, 20), 1]],
                    _dissolve: [[0, 0], [1, 0.2], [1, 0.3], [0, 0.7, "easeInOutCubic"]],
                    _definitePosition: [[0, 7, 250, 0]],
                    _position: [[0, 0, 0, 0], [0, Random(90, 400), Random(-50, -150), 1, "easeInOutQuart"]]
                }
            }
        }
    )
}



_obstacles.forEach(wall => {
    var randomSpread = Math.random();
    var duration = wall._duration + (halfJumpDuration * 2);
    var newDuration = wall._duration + (halfJumpDuration * 2) + randomSpread;
    wall._time -= randomSpread;
    wall._duration += randomSpread;

    var timeOffset = (newDuration - duration) / newDuration;
    var timeMultiplier = 1 - timeOffset;

    if (wall._customData) if (wall._customData._animation) {
        for (const property in wall._customData._animation) {
            wall._customData._animation[property].forEach(element => {
                var timeElement = element.length - 1;
                if (typeof element[timeElement] === 'string') timeElement -= 1;

                element[timeElement] *= timeMultiplier;
                element[timeElement] += timeOffset;
            })
        }
    }
})//makes it so the walls a spread out, no lag :)



_obstacles.push(
    {//environment 2 water
        _time: 197,
        _lineIndex: 0,
        _type: 1,
        _duration: 200,
        _width: 0,
        _customData: {
            _track: "environment2:water",
            _scale: [1000, 2, 2000],
            // _localRotation: [0, 180, 0],
            _interactable: false,
            _fake: true,
            _color: [0, 1.5 / 4, 2 / 4, 10 / 4],
            _animation: {
                _definitePosition: [[-500, -3.5, -50, 0]],
                _position: [
                    [0, 0, 0, 0],
                    [0, 0, -50, 1],
                ],
                _dissolve: [
                    [0, 0],
                    [1, 0.01],
                ],
            },
        },
    }
);
_customEvents.push(
    {
        "_time": 1,
        "_type": "AnimateTrack",
        "_data": {
            "_track": "environment2:water",
            "_duration": 1,
            _position: [[0, -100000, 0, 0]],
        }
    },
    {
        "_time": 199,
        "_type": "AnimateTrack",
        "_data": {
            "_track": "environment2:water",
            "_duration": 1,
            _position: [[0, 0, 0, 0]],
        }
    },
    {
        "_time": 327,
        "_type": "AnimateTrack",
        "_data": {
            "_track": "environment2:water",
            "_duration": 1,
            _position: [[0, -100000, 0, 0]],
        }
    }
)


// switchEnvironment(track,time,min,max,zoffset,rounding)
// switchEnvironment("environment1:Cubes", 0, 0, 0, 0, false)
// switchEnvironment("environment2:Cubes", 199, 0, 0, 0, false)

_events.forEach(x => {
    if (x._customData && x._type == 4 && x._customData._lightID == 124) {
        x._type = 1
    }
})


_obstacles.forEach(wall => {
    if (wall._customData == {}) {
        delete wall._customData;
    }
})




blenderCubesArray = []




_notes.sort(function (a, b) { return a._time - b._time; });
_events.sort(function (a, b) { return a._time - b._time; });
fs.writeFileSync(diffName, JSON.stringify(difficulty, null, 0));

//!-----------------------------------Remapper-----------------------------------
let map = new Difficulty(diffName, diffName);
let blendEnvCubes = new BlenderEnvironment(ENV.BTS.PILLAR.SCALE, ENV.BTS.PILLAR.ANCHOR, ENV.BTS.PILLAR.ID, "Regex");
let blendEnvLasers = new BlenderEnvironment(ENV.BTS.SOLID_LASER.SCALE, ENV.BTS.SOLID_LASER.ANCHOR, ENV.BTS.SOLID_LASER.ID, "Regex");
blendEnvCubes.animate([["environment1:Cubes", 0], ["environment2:Cubes", 199], ["environment3:Cubes", 327], ["environment4:Cubes", 359], ["", 391]])
blendEnvLasers.static("environment1:Lasers");
blendEnvLasers.static("environment2:Lasers");


map.require("Noodle Extensions", true);//already added those but fuck it
map.require("Chroma", true);//already added those but fuck it
map.save();

//!-----------------------------------lightIDs-----------------------------------
/*
100 - 103 - Big sky lightBox(type:1, lightID:20)
104 - 117 - Lasers in the beginning(type: 1, no lightID)
*/

